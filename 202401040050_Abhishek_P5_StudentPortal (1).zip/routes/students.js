const express = require('express');
const store = require('../lib/store');
const requireLogin = require('../middleware/auth');
const { prnParam, studentRules, collectErrors } = require('../middleware/validators');
const { validationResult } = require('express-validator');

const router = express.Router();

// Public: list with optional ?q= search and ?division= filter
router.get('/', async (req, res) => {
  let list = await store.readAll();
  const q = (req.query.q || '').toString().trim().toLowerCase();
  const division = (req.query.division || '').toString().toUpperCase();
  if (q) list = list.filter((s) => s.name.toLowerCase().includes(q) || s.prn.includes(q));
  if (division) list = list.filter((s) => s.division === division);
  res.render('students', { title: 'Students', students: list, q, division });
});

// Protected: add form (declared before /:prn so "new" is not read as a PRN)
router.get('/new', requireLogin, (req, res) =>
  res.render('student-form', { title: 'Add Student', errors: {}, values: {} }));

router.post('/', requireLogin, studentRules, async (req, res) => {
  const errors = collectErrors(req);
  if (Object.keys(errors).length) {
    return res.status(422).render('student-form', { title: 'Add Student', errors, values: req.body });
  }
  try {
    await store.add(req.body);
  } catch (err) {
    if (err.status === 409) {
      return res.status(409).render('student-form', {
        title: 'Add Student', errors: { prn: err.message }, values: req.body,
      });
    }
    throw err;
  }
  res.redirect(`/students/${req.body.prn}`);
});

// Route parameter with validation
router.get('/:prn', prnParam, async (req, res) => {
  if (!validationResult(req).isEmpty()) {
    const err = new Error('PRN in the URL must be exactly 12 digits');
    err.status = 400;
    throw err;
  }
  const student = await store.findByPrn(req.params.prn);
  if (!student) {
    const err = new Error(`No student found with PRN ${req.params.prn}`);
    err.status = 404;
    throw err;
  }
  res.render('student-detail', { title: student.name, student });
});

router.post('/:prn/delete', requireLogin, prnParam, async (req, res) => {
  if (!validationResult(req).isEmpty()) {
    const err = new Error('Invalid PRN'); err.status = 400; throw err;
  }
  await store.remove(req.params.prn);
  res.redirect('/students');
});

module.exports = router;
