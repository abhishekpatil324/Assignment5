const express = require('express');
const { body } = require('express-validator');
const { collectErrors } = require('../middleware/validators');

const router = express.Router();

router.get('/login', (req, res) => res.render('login', { title: 'Admin Login', errors: {}, values: {} }));

router.post('/login',
  body('username').trim().notEmpty().withMessage('Username is required'),
  body('password').notEmpty().withMessage('Password is required'),
  (req, res) => {
    const errors = collectErrors(req);
    if (Object.keys(errors).length) {
      return res.status(422).render('login', { title: 'Admin Login', errors, values: req.body });
    }
    const { ADMIN_USER, ADMIN_PASS } = req.app.locals.config;
    if (req.body.username !== ADMIN_USER || req.body.password !== ADMIN_PASS) {
      return res.status(401).render('login', {
        title: 'Admin Login', errors: { form: 'Invalid username or password' }, values: { username: req.body.username },
      });
    }
    const target = req.session.returnTo || '/students';
    req.session.regenerate(() => {
      req.session.user = { name: ADMIN_USER };
      res.redirect(target);
    });
  });

router.post('/logout', (req, res) => req.session.destroy(() => res.redirect('/')));

module.exports = router;
