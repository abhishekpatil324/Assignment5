const express = require('express');
const store = require('../lib/store');
const requireLogin = require('../middleware/auth');
const { prnParam, studentRules } = require('../middleware/validators');
const { validationResult } = require('express-validator');

const router = express.Router();
const started = Date.now();

router.get('/health', (req, res) =>
  res.json({ status: 'ok', uptimeSeconds: Math.round((Date.now() - started) / 1000), node: process.version }));

router.get('/students', async (req, res) => {
  const list = await store.readAll();
  res.json({ count: list.length, students: list });
});

router.get('/students/:prn', prnParam, async (req, res) => {
  const v = validationResult(req);
  if (!v.isEmpty()) return res.status(400).json({ success: false, errors: v.array().map((e) => e.msg) });
  const s = await store.findByPrn(req.params.prn);
  if (!s) return res.status(404).json({ success: false, error: 'Student not found' });
  res.json(s);
});

// Protected JSON endpoint: validation errors returned as JSON with 422
router.post('/students', requireLogin, studentRules, async (req, res) => {
  const v = validationResult(req);
  if (!v.isEmpty()) {
    const errors = {};
    v.array().forEach((e) => { if (!errors[e.path]) errors[e.path] = e.msg; });
    return res.status(422).json({ success: false, errors });
  }
  try {
    await store.add(req.body);
  } catch (err) {
    if (err.status === 409) return res.status(409).json({ success: false, error: err.message });
    throw err;
  }
  res.status(201).json({ success: true, student: req.body });
});

module.exports = router;
