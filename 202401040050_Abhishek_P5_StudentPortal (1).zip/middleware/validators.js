// express-validator rule sets
const { body, param, validationResult } = require('express-validator');

const prnParam = param('prn').matches(/^\d{12}$/).withMessage('PRN in the URL must be exactly 12 digits');

const studentRules = [
  body('prn').trim().matches(/^\d{12}$/).withMessage('PRN must be exactly 12 digits'),
  body('name').trim().isLength({ min: 3, max: 40 }).withMessage('Name must be 3 to 40 characters')
    .matches(/^[A-Za-z][A-Za-z .'-]*$/).withMessage("Name may contain only letters, spaces, . ' and -"),
  body('email').trim().isEmail().withMessage('Enter a valid email address').toLowerCase(),
  body('phone').trim().matches(/^[6-9]\d{9}$/).withMessage('Phone must be 10 digits starting with 6, 7, 8 or 9'),
  body('division').trim().toUpperCase().isIn(['A', 'B', 'C', 'D']).withMessage('Division must be A, B, C or D'),
  body('year').isInt({ min: 1, max: 4 }).withMessage('Year must be between 1 and 4').toInt(),
  body('cgpa').isFloat({ min: 0, max: 10 }).withMessage('CGPA must be between 0 and 10').toFloat(),
];

// Returns {} when valid, else { field: message }
function collectErrors(req) {
  const result = validationResult(req);
  const errors = {};
  result.array().forEach((e) => { if (!errors[e.path]) errors[e.path] = e.msg; });
  return errors;
}

module.exports = { prnParam, studentRules, collectErrors };
