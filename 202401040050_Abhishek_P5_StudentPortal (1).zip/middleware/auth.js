// Custom middleware 2: authentication check
module.exports = function requireLogin(req, res, next) {
  if (req.session && req.session.user) return next();
  if (req.originalUrl.startsWith('/api/')) {
    return res.status(401).json({ success: false, error: 'Login required' });
  }
  req.session.returnTo = req.originalUrl;
  res.redirect('/login');
};
