// 404 handler and central error-handling middleware (4 arguments)
function notFound(req, res, next) {
  const err = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  err.status = 404;
  next(err);
}

function errorHandler(err, req, res, next) {
  const status = err.status || 500;
  const message = status === 500 && process.env.NODE_ENV === 'production'
    ? 'Internal server error' : err.message;
  if (status === 500) console.error(err);
  if (res.headersSent) return next(err);
  const wantsJson = req.originalUrl.startsWith('/api/') || req.accepts(['html', 'json']) === 'json';
  if (wantsJson) return res.status(status).json({ success: false, status, error: message });
  res.status(status).render('error', { title: 'Error', status, message });
}

module.exports = { notFound, errorHandler };
