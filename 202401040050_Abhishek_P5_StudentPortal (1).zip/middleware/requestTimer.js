// Custom middleware 1: assigns a request id and measures response time
let counter = 0;
module.exports = function requestTimer(req, res, next) {
  req.id = ++counter;
  const start = process.hrtime.bigint();
  res.setHeader('X-Request-Id', req.id);
  res.on('finish', () => {
    const ms = Number(process.hrtime.bigint() - start) / 1e6;
    console.log(`[req ${req.id}] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${ms.toFixed(1)} ms)`);
  });
  next();
};
