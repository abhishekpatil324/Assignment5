const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

process.env.DATA_FILE = path.join(os.tmpdir(), `students-test-${process.pid}.json`);
process.env.ADMIN_PASS = 'test-pass';
fs.writeFileSync(process.env.DATA_FILE, '[]');

const createApp = require('../app');
let server, base;
test.before(() => new Promise((r) => { server = createApp().listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; r(); }); }));
test.after(() => { server.close(); fs.rmSync(process.env.DATA_FILE, { force: true }); });

async function login() {
  const res = await fetch(`${base}/login`, { method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'username=admin&password=test-pass' });
  return res.headers.get('set-cookie').split(';')[0];
}
const good = { prn: '202401040050', name: 'Abhishek Patil', email: 'a@b.com', phone: '9876543210', division: 'A', year: 3, cgpa: 8.5 };

test('home page renders', async () => { assert.strictEqual((await fetch(base)).status, 200); });
test('unknown route gives 404 JSON for API', async () => {
  const r = await fetch(`${base}/api/nothing`); assert.strictEqual(r.status, 404);
});
test('bad PRN parameter gives 400', async () => {
  assert.strictEqual((await fetch(`${base}/api/students/abc`)).status, 400);
});
test('protected API route needs login (401)', async () => {
  const r = await fetch(`${base}/api/students`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(good) });
  assert.strictEqual(r.status, 401);
});
test('invalid data gives 422 with field errors', async () => {
  const cookie = await login();
  const r = await fetch(`${base}/api/students`, { method: 'POST', headers: { 'Content-Type': 'application/json', cookie },
    body: JSON.stringify({ ...good, prn: '12', phone: '123', cgpa: 11 }) });
  const j = await r.json();
  assert.strictEqual(r.status, 422);
  assert.ok(j.errors.prn && j.errors.phone && j.errors.cgpa);
});
test('valid data gives 201, duplicate is rejected', async () => {
  const cookie = await login();
  const send = () => fetch(`${base}/api/students`, { method: 'POST', headers: { 'Content-Type': 'application/json', cookie }, body: JSON.stringify(good) });
  assert.strictEqual((await send()).status, 201);
  assert.strictEqual((await send()).status, 409);
});
